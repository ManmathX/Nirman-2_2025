import { users, type User, type InsertUser } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.currentId = 1;
    
    // Create default admin user for testing
    this.initializeDefaultUsers();
  }

  private async initializeDefaultUsers() {
    // Create admin user
    const adminUser: User = {
      id: this.currentId++,
      username: "admin",
      password: "admin", // As requested by user
      fullName: "Administrator",
      role: "admin",
      status: "active",
      createdAt: new Date()
    };
    this.users.set(adminUser.id, adminUser);

    // Create test user
    const testUser: User = {
      id: this.currentId++,
      username: "user",
      password: "user123",
      fullName: "Test User",
      role: "user",
      status: "active", 
      createdAt: new Date()
    };
    this.users.set(testUser.id, testUser);

    // Create facility owner
    const ownerUser: User = {
      id: this.currentId++,
      username: "owner",
      password: "owner123",
      fullName: "Facility Owner",
      role: "facility_owner",
      status: "active",
      createdAt: new Date()
    };
    this.users.set(ownerUser.id, ownerUser);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      id,
      username: insertUser.username,
      password: insertUser.password,
      fullName: insertUser.fullName,
      role: insertUser.role || "user",
      status: insertUser.status || "active",
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }
}

export const storage = new MemStorage();
