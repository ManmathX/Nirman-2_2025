import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth } from '../lib/supabase';
import type { User } from '@shared/schema';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: { username: string; password: string; fullName: string; role?: string }) => Promise<boolean>;
  updateProfile: (userData: Partial<User>) => Promise<boolean>;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    const getInitialSession = async () => {
      const { data } = await auth.getCurrentUser();
      if (data.user) {
        setUser(data.user);
      }
      setLoading(false);
    };

    getInitialSession();
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      console.log('Attempting login for:', username);
      const { data, error } = await auth.signIn(username, password);
      
      if (error) {
        console.error('Login error:', error.message);
        return false;
      }

      if (data) {
        setUser(data);
        console.log('Login successful for user:', data.fullName);
        return true;
      }

      return false;
    } catch (error) {
      console.error('Login exception:', error);
      return false;
    }
  };

  const register = async (userData: { username: string; password: string; fullName: string; role?: string }): Promise<boolean> => {
    try {
      console.log('Attempting registration for:', userData.username);
      const { data, error } = await auth.signUp(userData.username, userData.password, userData);
      
      if (error) {
        console.error('Registration error:', error.message);
        return false;
      }
      
      if (data) {
        console.log('User registered successfully:', data);
        setUser(data);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const updateProfile = async (userData: Partial<User>): Promise<boolean> => {
    // Simulate API call for now
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (user) {
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      return true;
    }
    return false;
  };

  const logout = async () => {
    try {
      await auth.signOut();
      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  const value = {
    user,
    login,
    logout,
    register,
    updateProfile,
    isAuthenticated: !!user,
    isLoading: loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}