// Local authentication API helper functions
export const auth = {
  signUp: async (username: string, password: string, userData?: any) => {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password, ...userData })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { data: null, error: { message: data.message } };
      }
      
      return { data: data.user, error: null };
    } catch (error) {
      return { data: null, error: { message: 'Network error' } };
    }
  },

  signIn: async (username: string, password: string) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { data: null, error: { message: data.message } };
      }
      
      return { data: data.user, error: null };
    } catch (error) {
      return { data: null, error: { message: 'Network error' } };
    }
  },

  signOut: async () => {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
      });
      
      if (!response.ok) {
        return { error: { message: 'Logout failed' } };
      }
      
      return { error: null };
    } catch (error) {
      return { error: { message: 'Network error' } };
    }
  },

  getCurrentUser: async () => {
    try {
      const response = await fetch('/api/auth/me');
      
      if (!response.ok) {
        return { data: { user: null } };
      }
      
      const data = await response.json();
      return { data: { user: data.user } };
    } catch (error) {
      return { data: { user: null } };
    }
  }
}