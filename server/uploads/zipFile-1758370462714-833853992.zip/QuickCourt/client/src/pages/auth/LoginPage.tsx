import React, { useState } from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Trophy, Eye, EyeOff, Loader, User, Shield, Building } from 'lucide-react';

type UserType = 'user' | 'admin' | 'facility_owner';

export default function LoginPage() {
  const [selectedUserType, setSelectedUserType] = useState<UserType>('user');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { login, isAuthenticated, user } = useAuth();
  const location = useLocation();

  if (isAuthenticated && user) {
    const dashboardPaths = {
      user: '/home',
      facility_owner: '/owner/dashboard',
      admin: '/admin/dashboard',
    };
    const from = location.state?.from || dashboardPaths[user.role];
    return <Navigate to={from} replace />;
  }

  const userTypeOptions = [
    {
      type: 'user' as UserType,
      label: 'Sports Player',
      icon: User,
      description: 'Book sports facilities',
      color: 'blue',
      credentials: { username: 'user', password: 'user123' }
    },
    {
      type: 'facility_owner' as UserType,
      label: 'Facility Owner',
      icon: Building,
      description: 'Manage your venues',
      color: 'purple',
      credentials: { username: 'owner', password: 'owner123' }
    },
    {
      type: 'admin' as UserType,
      label: 'Administrator',
      icon: Shield,
      description: 'Manage platform',
      color: 'green',
      credentials: { username: 'admin', password: 'admin' }
    }
  ];

  const selectedOption = userTypeOptions.find(option => option.type === selectedUserType);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;

    setLoading(true);
    setError('');

    try {
      console.log('Login attempt with:', username);
      const success = await login(username, password);
      if (!success) {
        setError('Invalid username or password. Please check your credentials.');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const fillCredentials = (type: UserType) => {
    const option = userTypeOptions.find(opt => opt.type === type);
    if (option) {
      setUsername(option.credentials.username);
      setPassword(option.credentials.password);
      setSelectedUserType(type);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex justify-center">
            <div className="p-3 bg-blue-600 rounded-2xl">
              <Trophy className="h-10 w-10 text-white" />
            </div>
          </div>
          <h2 className="mt-6 text-3xl font-bold text-gray-900">Welcome to QuickCourt</h2>
          <p className="mt-2 text-gray-600">Choose your account type and sign in</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* User Type Selection */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Select Account Type</h3>
            <div className="space-y-3">
              {userTypeOptions.map((option) => {
                const Icon = option.icon;
                const isSelected = selectedUserType === option.type;
                return (
                  <button
                    key={option.type}
                    type="button"
                    onClick={() => fillCredentials(option.type)}
                    className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                      isSelected
                        ? `border-${option.color}-500 bg-${option.color}-50`
                        : 'border-gray-200 hover:border-gray-300 bg-white'
                    }`}
                    data-testid={`button-select-${option.type}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${
                        isSelected 
                          ? `bg-${option.color}-500 text-white` 
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{option.label}</h4>
                        <p className="text-sm text-gray-600">{option.description}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          Demo: {option.credentials.username} / {option.credentials.password}
                        </p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Login Form */}
          <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
            <div className="flex items-center space-x-3 mb-6">
              {selectedOption && (
                <>
                  <div className={`p-2 rounded-lg bg-${selectedOption.color}-500 text-white`}>
                    <selectedOption.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{selectedOption.label} Login</h3>
                    <p className="text-sm text-gray-600">{selectedOption.description}</p>
                  </div>
                </>
              )}
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                    Username
                  </label>
                  <input
                    id="username"
                    name="username"
                    type="text"
                    autoComplete="username"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                    placeholder="Enter your username"
                    data-testid="input-username"
                  />
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors pr-12"
                      placeholder="Enter your password"
                      data-testid="input-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                      data-testid="button-toggle-password"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !username || !password}
                className={`w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-${selectedOption?.color || 'blue'}-600 hover:bg-${selectedOption?.color || 'blue'}-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-${selectedOption?.color || 'blue'}-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors`}
                data-testid="button-login"
              >
                {loading ? (
                  <Loader className="h-5 w-5 animate-spin" />
                ) : (
                  'Sign in'
                )}
              </button>

              <div className="text-center">
                <p className="text-sm text-gray-600">
                  Don't have an account?{' '}
                  <Link to="/register" className="font-medium text-blue-600 hover:text-blue-500" data-testid="link-register">
                    Sign up
                  </Link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}