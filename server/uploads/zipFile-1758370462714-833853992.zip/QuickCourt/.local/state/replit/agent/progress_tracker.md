[x] 1. Install the required packages
[x] 2. Replace Supabase authentication with local session-based authentication
[x] 3. Update user schema and storage interface for proper authentication
[x] 4. Create authentication API routes (login, register, logout, me)
[x] 5. Update frontend authentication context to use local API
[x] 6. Update login and register forms to use username instead of email
[x] 7. Test the application and verify it's working properly - authentication successful
[x] 8. Mark the import as completed using the complete_project_import tool